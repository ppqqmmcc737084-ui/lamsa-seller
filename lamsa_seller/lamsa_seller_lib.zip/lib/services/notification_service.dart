import 'package:http/http.dart' as http;
import 'dart:convert';

class NotificationService {
  static const String _appId = 'e691eb75-44b7-440c-8801-ca0f54cf66a1';
  static const String _apiKey = 'os_v2_app_42i6w5kew5cazcabzihvjt3gug6ds4uzhzgeakvkilwoxshecgjkaz33hpyagc3sdz2o4fpt74entq5umrhaia3vcsph3glgixzeypy';

  Future<void> sendToCustomer(String customerId, String message) async {
    try {
      await http.post(
        Uri.parse('https://api.onesignal.com/notifications'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic $_apiKey',
        },
        body: jsonEncode({
          'app_id': _appId,
          'include_aliases': {
            'external_id': [customerId]
          },
          'target_channel': 'push',
          'contents': {'en': message, 'ar': message},
          'headings': {'en': 'لمسة', 'ar': 'لمسة'},
        }),
      );
    } catch (e) {
      // ما نوقف باقي العملية لو فشل الإشعار، بس نطبع الخطأ
      // ignore: avoid_print
      print('فشل إرسال الإشعار: $e');
    }
  }
}